export const screenName = {
  DRAWER: 'DRAWER'
}
