export const colors = {
  mainBgColor: '#FFFFFF',
  drawerMenuText: '#595757',
  linkColor: '#42a5f5',
  fontColor: '#386DAB',
  topPageFontColor: '#4A4A4A',
  navBarTextColor: '#464B4D',
  placeholderText: '#C2C9CC',
  underlineAndroid: '#FFFFFF',
}
