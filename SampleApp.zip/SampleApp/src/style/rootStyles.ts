import { StyleSheet, Dimensions } from 'react-native'
import { colors } from './colors'
import { FontStyles } from './fontStyles'
const { width, height } = Dimensions.get('window')

export const RootStyles = StyleSheet.create({
  container: {
    flex: 1
  },
  containerBgSection1 : {

  },
  containerBgSection2 : {

  }
})
