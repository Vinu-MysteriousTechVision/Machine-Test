import React, { Component } from 'react'
import {
  FlatList,
  NetInfo,
  Text,
  View
} from 'react-native'
import { Navigation } from 'react-native-navigation'
import { screenName } from '../navigation'
import { ButtonIdEnum, setCustomTopBar } from '../utils/navigationController'

export interface IHomeComponentStateProps {
  productDatas: any
  isConnected: boolean
}

export interface IHomeComponentDispatchProps {
  onDidMount: () => void
  networkConnectionStatus: (isConnected: boolean) => void
  onTapOnNavigationButton: (isDrawerOpened: boolean) => void
}

interface IHomeProps extends IHomeComponentStateProps, IHomeComponentDispatchProps {/*Empty*/}

interface IHomeState {/*Empty*/}

export class Home extends React.Component<IHomeProps, IHomeState> {
  // Navigation options
  static get options() {
    return setCustomTopBar(ButtonIdEnum.Menu, 'Home')
  }
  private static isDrawerOpened: boolean = true

  constructor(props: IHomeProps) {
    super(props)
    this.props.onDidMount()
    Navigation.events().registerComponentDidAppearListener(({ componentId, componentName } : any) => {
      if (screenName.DRAWER === componentName) {
        Home.isDrawerOpened = true
      } else if (screenName.HOME === componentName) {
        Home.isDrawerOpened = false
      }
    })
    Navigation.events().registerComponentDidDisappearListener(({ componentId, componentName }: any) => {
      if (screenName.DRAWER === componentName) {
        Home.isDrawerOpened = false
      }
    })

    this.handleConnectivityChange = this.handleConnectivityChange.bind(this)
  }

  // Called when a TopBar button is pressed.
  public onNavigationButtonPressed(buttonId: any) {
    this.props.onTapOnNavigationButton(Home.isDrawerOpened)
  }

  componentDidMount() {
    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectivityChange)
    NetInfo.isConnected.fetch().then(isConnected => {
      this.props.networkConnectionStatus(isConnected)
    })
  }

  componentWillUnmount() {
    try {
      NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectivityChange);
    } catch (error) {
      /*Empty*/
    }
  }

  handleConnectivityChange = (isConnected: any) => {
    this.props.networkConnectionStatus(isConnected)
  }

  keyExtractor = (item: any, index: any) => String(index)

  renderListHeader = () => {
    return(
      <View style={{flex: 1, flexDirection: 'row', height: 44, backgroundColor: 'gray', justifyContent: 'space-between'}}>
        <View style={{width: 100, marginLeft: 5, justifyContent: 'center', alignItems: 'center'}}>
          <Text>Prodcut</Text>
        </View>
        <View style={{width: 75, justifyContent: 'center', alignItems: 'center'}}>
          <Text>Quantity</Text>
        </View>
        <View style={{width: 75, justifyContent: 'center', alignItems: 'center'}}>
          <Text>Prize</Text>
        </View>
      </View>
    )
  }

  renderCellItems = ({item}: any) => {
    const str = item.color
    const colorCode = str.toLowerCase()
    return(
      <View style={{flex: 1, flexDirection: 'row', height: 44, backgroundColor: '#dedede', margin: 5, justifyContent: 'space-between'}}>
        <View style={{width: 100, backgroundColor: colorCode, margin: 5, justifyContent: 'center', alignItems: 'center'}}>
          <Text>{item.name}</Text>
        </View>
        <View style={{width: 75, justifyContent: 'center', alignItems: 'center'}}>
          <Text>{item.quantity}</Text>
        </View>
        <View style={{width: 75, justifyContent: 'center', alignItems: 'center'}}>
          <Text>{item.prize}</Text>
        </View>
      </View>
    )
  }

  public render() {
    const {productDatas} = this.props
    return (
      <View style={{ flex: 1}}>
        <FlatList
          data={productDatas.products}
          ListHeaderComponent={this.renderListHeader}
          renderItem={this.renderCellItems}
          keyExtractor={this.keyExtractor}
        />
      </View>
    )
  }
}
