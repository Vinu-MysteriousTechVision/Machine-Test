import { reducerWithInitialState } from 'typescript-fsa-reducers'
import { actions } from './actions'

export interface State {
  productData: any
  isConnected: boolean
}

const initialState: State = {
  isConnected: true,
  productData: {}
}

/*
 * listDataLoadedHandler
 */
const listDataLoadedHandler = (state: State, payload: {data: any}): State => {
  return {
    ...state,
    productData: payload.data
  }
}

const connectionStateHandler = (state: State, payload: {status: boolean}): State => {
  return {
    ...state,
    isConnected: payload.status
  }
}


export const reducer = reducerWithInitialState(initialState)
  .case(actions.listDataLoaded, listDataLoadedHandler)
  .case(actions.connectionState, connectionStateHandler)
  .build()
