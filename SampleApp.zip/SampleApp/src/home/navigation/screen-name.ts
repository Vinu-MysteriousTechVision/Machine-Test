export const screenName = {
  HOME: 'HOME'
}
