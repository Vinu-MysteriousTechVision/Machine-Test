import { Provider } from 'react-redux'
import { Store } from 'redux'
import { registerContainerWithRedux } from '../../navigation'
import { RootState } from '../../reducer'
import { HomeContainer as HomeScreenContainer } from '../home.container'
import { screenName } from './screen-name'

export const register = (
  store: Store<RootState>,
  provider: typeof Provider
) => {
  registerContainerWithRedux(
    screenName.HOME,
    HomeScreenContainer,
    store,
    provider
  )
}
