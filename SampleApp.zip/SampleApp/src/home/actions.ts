import { Dispatch } from 'redux'
import actionCreatorFactory from 'typescript-fsa'
import { RootState } from '../reducer'

const actionCreator = actionCreatorFactory()

const listDataLoaded = actionCreator<{data: any}>('Home/listDataLoaded_Action')
const connectionState = actionCreator<{status: boolean}>('Home/connectionState')
const data = {
  products : [
    { id: 1, name: 'ABC', prize: 500, quantity: 5, color: 'Green'},
    { id: 2, name: 'DEF', prize: 400, quantity: 6, color: 'Blue'},
    { id: 3, name: 'ASD', prize: 300, quantity: 6, color: 'Red'},
    { id: 4, name: 'PSD', prize: 5300, quantity: 6, color: 'Green'},
    { id: 5, name: 'OSD', prize: 1300, quantity: 6, color: 'Gray'}]}

/*
 * method loadListData
 **/
const loadListData = (): any => {
  return async (dispatch: Dispatch<any>, getState: () => RootState) => {
    const isConnected = getState().home.isConnected
    if (isConnected) {
      fetch('https://facebook.github.io/react-native/movies.json')
        .then((response) => response.json())
        .then((responseJson) => {
          dispatch(listDataLoaded({data}))
        })
        .catch((error) => {
          /* Error */
        })
    } else {
      alert('Network Error')
    }
  }
}

export const actions = {
  loadListData,
  listDataLoaded,
  connectionState
}
