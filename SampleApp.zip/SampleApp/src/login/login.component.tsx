import React, { Component } from 'react'
import {
  ActivityIndicator,
  Dimensions,
  StatusBar,
  Text,
  TextInput,
  TextInputProperties,
  TextInputStatic,
  TouchableHighlight,
  View
} from 'react-native'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { CustomButton } from '../commonComponents/custom.ButtonComponent'
import { CommonStyles, LoginStyle } from '../style'
import { Utils } from '../utils/utils'
import { validateEmail, validatePassword } from '../utils/validator'

import dismissKeyboard from 'dismissKeyboard'
import TextInputState from 'TextInputState'
const windowWidth = Dimensions.get('window').width // full width
const windowHeight = Dimensions.get('window').height // full height

export interface ILoginComponentStateProps {
  isLoading: boolean
  errorText: string
}

// NOTE: Component must not know what will happen when button pressed.
// just passing event to parent (container) and container handles the event by emitting action of Redux.
export interface ILoginComponentDispatchProps {
  onLogin: (email: string, password: string) => void
  onForgotPassword: () => void
}

interface ILoginProps extends ILoginComponentStateProps, ILoginComponentDispatchProps {}

type NameType = 'email' | 'password' | 'confirmPassword'

type FormState = { [name in NameType]: string }

type TextInputField = React.Component<TextInputProperties, React.ComponentState> & TextInputStatic

interface ILoginState {
  form: FormState
  errorMessage: string
}

export class Login extends React.Component<ILoginProps, ILoginState> {
  // Navigation options
  static get options() {
    return {
      topBar: {
        drawBehind: true,
        visible: false,
        animate: false
      }
    }
  }

  public state: ILoginState = {
    form: {
      email: '',
      password: '',
      confirmPassword: ''
    },
    errorMessage: ''
  }

  private formRef: { [name in keyof FormState]: TextInputField | null } = {
    email: undefined,
    password: undefined,
    confirmPassword: undefined
  }

  constructor(props: ILoginProps) {
    super(props)
    this.onChangeEmailTextinput = this.onChangeEmailTextinput.bind(this)
    this.onChangePWDTextinput = this.onChangePWDTextinput.bind(this)

    this.onSubmit = this.onSubmit.bind(this)
    this.onRequestSubmit = this.onRequestSubmit.bind(this)
    this.onFocus = this.onFocus.bind(this)
  }

  public componentDidMount() {
    /**/
  }

  public render() {
    const { isLoading, onForgotPassword } = this.props
    const { email, password } = this.state.form
    const { errorMessage } = this.state

    return (
    <View style={{ flex: 1, backgroundColor: 'transparent'}}>
      <StatusBar backgroundColor='#1A2A39' barStyle='light-content'/>
      <View style={{ backgroundColor: '#1A2A39', height: Utils.getStatusBarHeight()}}/>
      <KeyboardAwareScrollView
        scrollEnabled={true}
        enableAutomaticScroll={true}
        showsVerticalScrollIndicator={false}
        style={LoginStyle.container}
        contentContainerStyle={{ alignItems: 'center' }}
        keyboardShouldPersistTaps={'always'}
        enableOnAndroid={true}
      >
        <View style={{flex: 1}}>
          <View style={{height: windowHeight / 2, width: windowWidth, backgroundColor: '#1A2A39'}}/>
          <View style={{height: windowHeight / 2, width: windowWidth, backgroundColor: '#ECECF1'}}/>
          <View style={{position: 'absolute', top: 0, bottom: 0, left: 0, right: 0, flex: 1, backgroundColor: 'transparent', justifyContent: 'center', alignItems: 'center'}}>
            <View style={{ padding: 20, marginHorizontal: 20, justifyContent: 'center', alignItems: 'center', backgroundColor: '#EAEEF2', borderWidth: 5, borderRadius: 5, borderColor: '#F5F5F5'}}>
              <TextInput
                ref={(refObj: TextInputField) => { this.formRef.email = refObj }}
                style={[CommonStyles.textinput, { marginTop: 32, width: 250 }]}
                placeholder='User name or E-mail'
                placeholderTextColor='#C2C9CC'
                underlineColorAndroid='#FFFFFF'
                onChangeText={this.onChangeEmailTextinput}
                value={email}
                returnKeyType='next'
                returnKeyLabel='Next'
                keyboardType='email-address'
                blurOnSubmit={false}
                onFocus={this.onFocus}
                onSubmitEditing={this.focusNextField(this.formRef.password)}
              />
              <TextInput
                ref={(refObj: TextInputField) => { this.formRef.password = refObj }}
                style={[CommonStyles.textinput, { marginTop: 32, width: 250 }]}
                placeholder='Password'
                placeholderTextColor='#C2C9CC'
                underlineColorAndroid='#FFFFFF'
                secureTextEntry={true}
                onChangeText={this.onChangePWDTextinput}
                value={password}
                returnKeyType='done'
                returnKeyLabel='Done'
                onSubmitEditing={this.onSubmit}
                blurOnSubmit={true}
                onFocus={this.onFocus}
              />
              <View style={{ width: 250, alignItems: 'flex-end', marginTop: 15}}>
                <TouchableHighlight onPress={onForgotPassword} underlayColor='#EAEEF2'>
                  <Text style={LoginStyle.forgotPasswordText}>Forget password?</Text>
                </TouchableHighlight>
              </View>
              <Text style={[LoginStyle.errorText]}>{errorMessage}</Text>
              <CustomButton
                title='Login'
                onPressAction={this.onRequestSubmit}
                buttonStyle={{ borderRadius: 5, width: 250, marginTop: 5 }}
                disabled={!this.isFillAllRequiredField}
              />
            </View>
          </View>
        </View>
        <ActivityIndicator animating={isLoading} style={[LoginStyle.activityIndicator, { width: isLoading ? 100 : 0, height: isLoading ? 100 : 0 }]} size='large' color='#262626'/>
      </KeyboardAwareScrollView>

    </View>
    )
  }

  private checkValidation(email: string, password: string): boolean {
    let errorMsg: string = ''
    let isValidForm: boolean = true

    if (!validateEmail(email) && email !== '') {
      errorMsg = 'E-mail address is wrong' // 'E-mail address is wrong'
      isValidForm = false
    } else if (!validatePassword(password) && password !== '') {
      errorMsg = 'The password is in correct' // 'The password is in correct'
      isValidForm = false
    }

    this.setState({ errorMessage: errorMsg })

    return isValidForm
  }

  private onChangeEmailTextinput(text: string) {
    this.setState({
      form: {
        ...this.state.form,
        email: text
      }
    })
    this.checkValidation(text, this.state.form.password)
  }

  private onChangePWDTextinput(text: string) {
    this.setState({
      form: {
        ...this.state.form,
        password: text
      }
    })
    this.checkValidation(this.state.form.email, text)
  }

  private onSubmit() {
    dismissKeyboard()
    TextInputState.blurTextInput(TextInputState.currentlyFocusedField())
  }

  private onRequestSubmit() {
    dismissKeyboard()
    TextInputState.blurTextInput(TextInputState.currentlyFocusedField())

    const { email, password } = this.state.form
    if (!this.checkValidation(email, password)) {
      return
    }
    this.props.onLogin(email, password)
  }

  private onFocus() {
    const { email, password } = this.state.form
    if (email !== '' || password !== '') {
      this.checkValidation(email, password)
    }
  }

  private focusNextField = (nextField: TextInputField | null) => () => {
    const { email, password } = this.state.form
    this.checkValidation(email, password)

    if (nextField !== null) {
      nextField.focus()
    }
  }

  private get isFillAllRequiredField(): boolean {
    const { email, password } = this.state.form
    return validateEmail(email) && validatePassword(password)
  }
}
