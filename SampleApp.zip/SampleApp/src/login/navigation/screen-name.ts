export const screenName = {
  LOGIN: 'LOGIN',
}
