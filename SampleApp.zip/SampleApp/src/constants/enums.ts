export enum DrawerMenuEnum {
  Home = 1,
  Logout
}

export enum DrawerMenuSectionEnum {
  Section_1 = 'SECTION_1',
  Section_2 = 'SECTION_2'
}
