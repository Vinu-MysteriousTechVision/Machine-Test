/** @format */

import Start from './src/start';
const start = new Start();
